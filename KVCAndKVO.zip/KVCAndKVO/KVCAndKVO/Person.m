//
//  Person.m
//  KVCAndKVO
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "Person.h"

@implementation Person
- (instancetype)init
{
    self = [super init];
    if (self) {
        [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(addAge) userInfo:nil repeats:YES];
    }
    return self;
}

-(void)addAge{
    self.age++;
}
@end
