//
//  ViewController.m
//  KVCAndKVO
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Person *p = [[Person alloc]init];
    p.father = [[Person alloc]init];
    p.name = @"刘德华";
    p.age = 38;
//    KVC对属性赋值
    [p setValue:@"张学友" forKey:@"name"];
    [p setValue:@(33) forKey:@"age"];
    [p setValue:@"赵四儿" forKeyPath:@"father.name"];
    NSLog(@"%@--%d---%@",[p valueForKey:@"name"],p.age,p.father.name);
    
    //监听年龄的改变
    [p addObserver:self forKeyPath:@"age" options:NSKeyValueObservingOptionNew context:nil];
    
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    Person *p = object;
    
    NSLog(@"%d",p.age);
    
    
    
}

@end
