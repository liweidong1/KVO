//
//  Person.h
//  KVCAndKVO
//
//  Created by tarena on 16/4/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
@property (nonatomic, copy)NSString *name;
@property (nonatomic)int age;
@property (nonatomic, strong)Person *father;
@end
